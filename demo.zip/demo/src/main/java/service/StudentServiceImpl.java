package service;

public class StudentServiceImpl implements StudentService{

}
