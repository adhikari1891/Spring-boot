package service;

import model.Fruits;
import org.springframework.stereotype.Service;
import pojo.FruitsPojo;
@Service
public interface FruitService {
    //create/save fruit entities in database
    Fruits saveFruit(FruitsPojo fruitsPojo);

}
