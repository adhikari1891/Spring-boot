package service;

import model.Fruits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pojo.FruitsPojo;
import repo.FruitsRepo;

@Service
public class FruitServiceImpl implements FruitService{

    //Makes the object of this class for only once in the whole class
    @Autowired
    FruitsRepo fruitsRepo;


    @Override
    public Fruits saveFruit(FruitsPojo fruitsPojo) {
        Fruits entity = new Fruits();

        // get the fruitspojo elements and set it in the entity
        entity.setName(fruitsPojo.getName());
        entity.setPrice(fruitsPojo.getPrice());

        //saving the fruit in database with help of fruitsRepo
        fruitsRepo.save(entity);
        return entity;

    }



}
