package pojo;

public class CostumerPojo {
    private int id;
    private String Name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    private String email;
    private String gender;

    public CostumerPojo(int id, String name, String email, String gender) {
        this.id = id;
        Name = name;
        this.email = email;
        this.gender = gender;
    }
}
