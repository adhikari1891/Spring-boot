package model;

import javax.persistence.*;

@Entity
@Table(name = "Fruit-name")

public class Fruits {

    @Id
    @SequenceGenerator(name = "fruits_seq", sequenceName = "fruits_seq", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "fruits_seq", strategy = GenerationType.SEQUENCE)
    private Integer id;

    private String name;

    private Double price;

    @Column(name = "address")

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Fruits() {
    }

    public Fruits(Integer id, String name, Double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}
