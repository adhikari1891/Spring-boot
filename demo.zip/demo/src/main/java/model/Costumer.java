package model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "Costumer")
@Getter
@Setter

public class Costumer {

    @Id
    @SequenceGenerator(name = "fruits_seq", sequenceName = "fruits_seq", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "fruits_seq", strategy = GenerationType.SEQUENCE)

    private int id;
    private String Name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    private String email;
    private String gender;

    public Costumer(int id, String name, String email, String gender) {
        this.id = id;
        Name = name;
        this.email = email;
        this.gender = gender;
    }

    public Costumer() {
    }
}
