package repo;

import model.Fruits;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FruitsRepo extends JpaRepository<Fruits,Integer> {
}
