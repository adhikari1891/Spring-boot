package repo;

import model.Costumer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CostumerRepo extends JpaRepository<Costumer, Integer> {
}
