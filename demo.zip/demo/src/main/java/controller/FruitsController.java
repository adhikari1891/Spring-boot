package controller;

import model.Fruits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pojo.FruitsPojo;
import service.FruitService;

@RestController
@RequestMapping("/fruits")
public class FruitsController {

    @Autowired

    FruitService fruitService;

    @PostMapping("/save")
    public Fruits saveFruits(@RequestBody FruitsPojo fruitsPojo){
        return fruitService.saveFruit(fruitsPojo);

    }
}
